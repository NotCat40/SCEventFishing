package com.sceventhunters.sceventfishing.util

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.widget.Toast
import androidx.documentfile.provider.DocumentFile
import com.sceventhunters.sceventfishing.R
import com.sceventhunters.sceventfishing.data.model.AppMode
import java.io.File

fun getBaseUrlForPackage(packageName: String): String {
    return when (packageName) {
        "com.tencent.tmgp.supercell.brawlstars" -> "https://event-assets.tencent-cloud.com/"
        "com.supercell.clashroyale" -> "https://event-assets.clashroyale.com/"
        "com.tencent.tmgp.supercell.clashroyale" -> "https://event-assets.tencent-cloud.com/"
        else -> "https://event-assets.brawlstars.com/"
    }
}

fun copyUrlsToClipboard(
    context: Context,
    packageName: String,
    eventFiles: List<String>,
    copyWithoutLink: Boolean = false
) {
    if (eventFiles.isEmpty()) return
    val clipboardManager = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val baseUrl = getBaseUrlForPackage(packageName)
    val allText = eventFiles.joinToString("\n") { filePath ->
        val fileName = if (filePath.startsWith("content://")) {
            DocumentFile.fromSingleUri(context, Uri.parse(filePath))?.name ?: "unknown"
        } else {
            File(filePath).name
        }
        if (copyWithoutLink) fileName else baseUrl + fileName
    }
    clipboardManager.setPrimaryClip(ClipData.newPlainText("Event Files", allText))
    Toast.makeText(context, context.getString(R.string.copied_items_toast, eventFiles.size), Toast.LENGTH_SHORT).show()
}

fun extractFilesToDownloadEvents(context: Context, packageName: String, eventFiles: List<String>, onComplete: () -> Unit) {
    if (eventFiles.isEmpty()) return
    val eventsDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "events")
    if (!eventsDir.exists()) eventsDir.mkdirs()

    var successCount = 0
    eventFiles.forEach { filePath ->
        val fileName = if (filePath.startsWith("content://")) {
            DocumentFile.fromSingleUri(context, Uri.parse(filePath))?.name ?: "unknown"
        } else {
            File(filePath).name
        }
        val destFile = File(eventsDir, fileName)

        try {
            if (filePath.startsWith("content://")) {
                context.contentResolver.openInputStream(Uri.parse(filePath))?.use { input ->
                    destFile.outputStream().use { output ->
                        input.copyTo(output)
                    }
                }
                successCount++
            } else {
                val result = RootShell.runCommand("cp \"$filePath\" \"${destFile.absolutePath}\"")
                if (result.isEmpty()) successCount++
            }
        } catch (e: Exception) {
            // Log error
        }
    }
    Toast.makeText(context, context.getString(R.string.extracted_files_toast, successCount), Toast.LENGTH_SHORT).show()
    onComplete()
}

fun getEventFiles(
    context: Context,
    mode: AppMode,
    packageName: String,
    compatFolderUri: String? = null,
    extensions: List<String> = listOf(".sc", ".jpg", ".png")
): List<String> {
    return when (mode) {
        AppMode.REGULAR -> {
            val path = "/data/data/$packageName/cache/events/"
            val res = RootShell.runCommand("[ -d \"$path\" ] && find $path -type f \\( ${extensions.joinToString(" -o ") { "-name '*$it'" }} \\) 2>/dev/null")
            res.filter { it.startsWith(path) }.distinctBy { it.substringAfterLast("/") }.sorted()
        }
        AppMode.COMPATIBILITY -> {
            if (compatFolderUri == null) return emptyList()
            try {
                val treeUri = Uri.parse(compatFolderUri)
                val documentFile = DocumentFile.fromTreeUri(context, treeUri)
                documentFile?.listFiles()?.filter { file ->
                    file.isFile && extensions.any { ext -> file.name?.endsWith(ext) == true }
                }?.map { it.uri.toString() } ?: emptyList()
            } catch (e: Exception) {
                emptyList()
            }
        }
        AppMode.DEMO -> {
            listOf(
                "/demo/events/event_1.sc",
                "/demo/events/event_2.sc",
                "/demo/events/background.jpg",
                "/demo/events/icon.png"
            )
        }
    }
}
